import React from 'react'
// import { Divider } from 'antd';
export default class Detail extends React.Component {
  render(){
    return(
      <div>
        这里作为第二个子路由模块 
      </div>
    )
  }
}