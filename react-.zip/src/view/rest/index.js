import anchor from './anchor'
import backTop from './backTop'
import configProvider from './configProvider'
import divider from './divider'
import localeProvider from './localeProvider'
export {
  anchor,
  backTop,
  configProvider,
  divider,
  localeProvider
}