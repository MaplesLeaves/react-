// 布局layout
import React, { Component } from 'react'
import { Typography } from 'antd';
const { Title, Paragraph, Text } = Typography;
class layout extends Component {
  static propTypes = {

  }

  render() {
    return (
      <div>
        
      </div>
    )
  }
}

export default layout
