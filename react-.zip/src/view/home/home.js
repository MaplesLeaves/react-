import React from 'react'
// import { Divider } from 'antd';
export default class HomePage extends React.Component {
  render(){
    return(
      <div>
        这是一个首页路由
      </div>
    )
  }
}