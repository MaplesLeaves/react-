import React, { Component } from 'react'

export class model extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}

export default model
